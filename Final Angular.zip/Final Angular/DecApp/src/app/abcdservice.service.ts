import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AbcdserviceService {

  constructor() { }

  met() {
    return "hello abcd service";
  }
}
