import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthenticationService } from './authentication.service';
import { Cart } from './model/cart';
import { Product } from './model/product';
import { PurchaseHistory } from './model/purchase-history';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productObs!: Observable<Product[]>;

  productList!: Product[];
  cartList: Cart[] = [];
  purchaseList: PurchaseHistory[] = [];

  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService) { }

  // getProduct(code: any) {
  //   let token = 'Bearer ' + this.authenticationService.getToken();
  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       'Authorization': token
  //     })
  //   }
  //   return this.httpClient.get("http://localhost:8083/product-service/smart-shop/products/" + code, httpOptions);
  // }

  // deleteProduct(code: any) {
  //   let token = 'Bearer ' + this.authenticationService.getToken();
  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       'Authorization': token
  //     })
  //   }
  //   return this.httpClient.delete("http://localhost:8083/product-service/smart-shop/products/" + code, httpOptions);
  // }

  getAllProducts() {
    // let token = 'Bearer ' + this.authenticationService.getToken();
    // const httpOptions = {
    //   headers: new HttpHeaders({
    //     'Content-Type': 'application/json',
    //     'Authorization': token
    //   })
    // };
    
    
    return this.httpClient.get<any>("http://localhost:9091/product/GetAllProducts");

    // this.productList = this.getProductsHardCoded();

    // let obs = new Observable((observer) => {
    //   observer.next(this.productList);
    // })
    // return obs;

  }

  getCartList() {
 

    // let obs = new Observable((observer) => {
    //   observer.next(this.cartList);
    // })
    // return obs;

    return this.httpClient.get<any>("http://localhost:9091/buyerMicro/getAllCarts/" + this.authenticationService.getBuyer().id);
  }

  addToCart(cart: Cart) {
    // post call

    // this.cartList.push(cart);
    
    return this.httpClient.post<any>("http://localhost:9091/buyerMicro/addToCart", cart);
  }

  removeFromCart(cartId: number) {
    // this.cartList.forEach(cartItem => {
    //   if (cartItem.product.pid === cart.product.pid) {
    //     cartItem.purchaseStatus = true;
    //   }
    // });

    return this.httpClient.delete<any>("http://localhost:9091/buyerMicro/DeleteFromCart" + cartId);
  }

  checkout(cart: Cart) {
    // let purchaseHistory: PurchaseHistory = {
    //   id: 0,
    //   cart: cart,
    //   purchaseQuantity: cart.purchaseQuantity,
    //   buyer: this.authenticationService.getBuyer(),
    //   purchaseDate: new Date()
    // }

    // this.purchaseList.push(purchaseHistory);

    // this.cartList.forEach(cartItem=>{
    //   if(cartItem.product.pid === cart.product.pid){cartItem.purchaseStatus = true;}
    // });



    // let obs = new Observable((observer) => {
    //   observer.next(cart);
    // })
    // return obs;

    return this.httpClient.put<any>("http://localhost:9091/buyerMicro/updateCart", cart);
  }

  // getPurchaseList() {

  //   let obs = new Observable((observer) => {
  //     observer.next(this.purchaseList);
  //   })
  //   return obs;

  //   // return this.httpClient.get<any>("http://localhost:9091/product/GetAllProducts");
  // }



  






  getProductsHardCoded() {
    let productList: Product[] = [
      {
        pid: 1,
        productname: "One Plus",
        productModel: "string",
        brandName: "string",
        category: "Electronics",
        subCategory: "Mobile",
        productPrice: 200,
        quantity: 1000,
        image: "https://i.pcmag.com/imagery/reviews/01pr6hmgqz7A5wX5hSQWqRs-1.fit_lim.size_625x365.v1632764534.jpg",
        productSpecs: "string",
        sellerId: 2,
        status: "active"
      },
      {
        pid: 2,
        productname: "Travel Bag",
        productModel: "abcd",
        brandName: "abcd",
        category: "Electronics",
        subCategory: "Mobile",
        productPrice: 200,
        quantity: 1000,
        image: "https://5.imimg.com/data5/TL/KN/MY-33478789/trolley-travel-bag-500x500.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      },
      {
        pid: 3,
        productname: "Shirt",
        productModel: "abcd",
        brandName: "abcd",
        category: "Fashion",
        subCategory: "Clothing",
        productPrice: 200,
        quantity: 1000,
        image: "https://5.imimg.com/data5/YU/MT/NS/SELLER-3664875/mens-shirts-500x500.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      },
      {
        pid: 4,
        productname: "Jeans",
        productModel: "abcd",
        brandName: "abcd",
        category: "Fashion",
        subCategory: "Clothing",
        productPrice: 200,
        quantity: 1000,
        image: "https://www.realmenrealstyle.com/wp-content/uploads/2021/07/mens-jeans.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      },
      {
        pid: 5,
        productname: "Shoe",
        productModel: "abcd",
        brandName: "abcd",
        category: "Fashion",
        subCategory: "Footwear",
        productPrice: 200,
        quantity: 1000,
        image: "https://assets.ajio.com/medias/sys_master/root/h5a/h59/13018715881502/-1117Wx1400H-460342492-blue-MODEL.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      }

    ];
    return productList;
  }

}