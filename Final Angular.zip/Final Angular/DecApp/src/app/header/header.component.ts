import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  loggedInUser: string = "anonymous";
  name!: string;
  constructor(private router: Router, private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.name = this.authenticationService.getUserID();
  }

  toLogin(){
    this.router.navigate(['login']);
  }

  toRegister(){
    this.router.navigate(['register']);
  }

  toHome(){
    this.router.navigate(['home']);
  }

  toBill(){
    this.router.navigate(['bill']);
  }

  // isOwner() {
  //   let roleCheck = false;
  //   if (this.authenticationService.getUserType() == 'O' && this.authenticationService.getStatus()  =='A') {
  //     roleCheck = true;
  //   }
  //   return roleCheck;
  // }

  // isAdmin() {
  //   let roleCheck = false;
  //   if (this.authenticationService.getUserType() == 'A' && this.authenticationService.getStatus()  =='A') {
  //     roleCheck = true;
  //   }
  //   return roleCheck;
  // }

  // isCustomer() {
  //   let roleCheck = false;
  //   if (this.authenticationService.getUserType() == 'U' && this.authenticationService.getStatus()  =='A') {
  //     roleCheck = true;
  //   }
  //   return roleCheck;
  // }

  // isAnonymous() {
  //   let roleCheck = false;
  //   if (this.authenticationService.getUserType() == '' || this.authenticationService.getStatus()  =='' || this.authenticationService.getStatus()  =='P' || this.authenticationService.getStatus()  =='D') {
  //     roleCheck = true;
  //   }
  //   return roleCheck;
  // }

  toProducts() {
    this.router.navigate(['products']);
  }

  toCart() {
    this.router.navigate(['cart']);
  }

  toPurchaseHistory() {
    this.router.navigate(['purchase-history']);
  }

  toAddProduct() {
    this.router.navigate(['add-product']);
  }
  toAddOffer(){
    this.router.navigate(['add-offer']);
  }

  toEditProduct() {
    this.router.navigate(['edit-product']);
  }

  toRequest() {
    this.router.navigate(['registration-request']);
  }

  toLogout() {
    this.authenticationService.setIsLoggedIn(false);
    this.router.navigate(['login']);
  }

  isLoggedIn() {
    return this.authenticationService.getIsLoggedIn();
  }

}
