export interface Buyer {
    id: number,
    buyerName: string,
    password: string,
    email: string
}
