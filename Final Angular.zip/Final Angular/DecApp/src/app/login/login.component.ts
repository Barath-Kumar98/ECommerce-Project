import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { Buyer } from '../model/buyer';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  getUserID: string = "";
  getPassword: string = "";
  invalid: boolean = false;
  constructor(private router: Router, private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.invalid = false;
  }

  goToRegister() {
    this.router.navigate(['register']);
  }

  goToForgotUserID() {
    this.router.navigate(['forgot-password', 'id']);
  }

  goToForgotPassword() {
    this.router.navigate(['forgot-password', 'password']);
  }

  authenticate() {
    this.authenticationService.authenticate(this.getUserID, this.getPassword).subscribe((response: Buyer) => {
      if (response != null) {
        let buyer:Buyer = response;
        console.log('buyer');
        console.log(buyer);
        this.invalid = false;
        // this.authenticationService.setToken(response);
        this.authenticationService.setUserID(this.getUserID);
        this.authenticationService.setIsLoggedIn(true);
        this.authenticationService.setBuyer(buyer);

        this.router.navigate(['products']);
      } else {
        this.invalid = true;
      }

    },
      (error: any) => {
        this.invalid = true;
      }
    );
  }

}
