package com.training.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BUYER")
public class Buyer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Override
	public String toString() {
		return "Buyer [id=" + id + ", username=" + buyerName + ", password=" + password + "]";
	}

	@Column(name="buyerName")
    private String buyerName;
    
    @Column(name="password")
    private String password;
    
    @Column(name="email")
    private String email;
   
  //  private Product product;
    
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getbuyerName() {
		return buyerName;
	}


	public void setbuyerName(String buyerName) {
		this.buyerName = buyerName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}