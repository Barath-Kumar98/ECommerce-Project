
package com.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.BuyerDao;
import com.training.model.Buyer;
import com.training.model.ShoppingCart;
import com.training.repository.BuyerRepository;
import com.training.repository.ShoppingCartRepository;

import exception.RecordNotFoundException;

@Service
public class BuyerService  implements IBuyerService{

	@Autowired
	BuyerRepository repository;
	
	@Autowired
	ShoppingCartRepository repository1;
	
	@Autowired
	private BuyerDao buyerDao;

	public Buyer createBuyer(Buyer entity) throws RecordNotFoundException {
		System.out.println("sam entity is::" + entity);
		entity = repository.save(entity);

		return entity;
	}
	
	@Override
	public java.util.List<ShoppingCart> showCart(int buyerid) {
		return repository1.showCart(buyerid);
	}
	
	public Buyer findOne(String buyerName) {
		return buyerDao.findBybuyerName(buyerName);
	}

	@Override
	public Buyer save(Buyer user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Buyer> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}
	

	@Override
	public Buyer findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
