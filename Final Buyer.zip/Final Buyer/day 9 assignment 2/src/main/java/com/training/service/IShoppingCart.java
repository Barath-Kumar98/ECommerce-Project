package com.training.service;

import java.util.List;

import com.training.model.ShoppingCart;


public interface IShoppingCart {

	com.training.model.ShoppingCart addToCart(ShoppingCart cart);

	 List<ShoppingCart> showCart(int byuerId);
	 
	 public Integer deleteProductsFromCart(int pid);

	ShoppingCart updateCart(ShoppingCart cart);

}
