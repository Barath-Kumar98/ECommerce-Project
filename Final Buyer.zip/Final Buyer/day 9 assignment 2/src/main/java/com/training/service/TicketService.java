package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.model.Ticket;
import com.training.repository.TicketRepo;

@Service
public class TicketService {
	
	@Autowired
	private TicketRepo tRepo;
	
	
	public void saveTickets(Ticket ticket) {
		
		tRepo.save(ticket);
		System.out.println("Data Saved");
	}
	
	public List<Ticket> getTickets() {
		return tRepo.findAll();
	}

	public int cancelTicket(int id) {
		tRepo.deleteById(id);
		return id;
	}

	public List<Ticket> findByFromPlaceAndToPlace(String fromPlace, String toPlace) {
		List<Ticket> fp = tRepo.findByFromPlaceAndToPlaceIgnoreCase(fromPlace, toPlace);
		return fp;
	}
	
	
	public List<Ticket> findTicketByFromPlaceAndToPlaceUsingJPQA(String fromPlace, String toPlace) {
		return tRepo.findTicketByFromPlaceAndToPlaceIgnoreCase(fromPlace, toPlace);
	}
	
	public List<Ticket> findTicketUsingNativeQuery(String fromPlace, String toPlace) {
		return tRepo.findTicket(fromPlace, toPlace);
	}
	
}
