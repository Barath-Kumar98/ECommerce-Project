package com.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{


//
List<Product> findBySellerId(int seller_Id);


List<Product> findProductByCategory(String category);



//NAtive Query Working fine
// @Query(value="select * from productdetail where seller_id = :seller_Id", nativeQuery=true)
// List<Product> findBySellerId(int seller_Id);

}

