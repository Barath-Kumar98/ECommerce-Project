package com.training.repositorydao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.model.ShoppingCart;

public interface ICartInterface extends JpaRepository<ShoppingCart,Integer>{
	
	@Query(value = "select * from cart where buyerid in(?1)", nativeQuery = true)
	public List<ShoppingCart> getCartProduct(List<Integer> cList);
	
}
