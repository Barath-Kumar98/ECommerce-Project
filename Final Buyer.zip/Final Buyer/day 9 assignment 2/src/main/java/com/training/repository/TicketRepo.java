package com.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.training.model.Ticket;

public interface TicketRepo extends JpaRepository<Ticket, Integer>{

	List<Ticket> findByFromPlaceAndToPlaceIgnoreCase(String fromPlace, String toPlace);
	
	@Query("SELECT u FROM Ticket u WHERE u.fromPlace = ?1 and u.toPlace = ?2")
	List<Ticket> findTicketByFromPlaceAndToPlaceIgnoreCase(String fromPlace, String toPlace);

	@Query(value="select * from ticket where from_place like '%a%' and to_place like '%u%'", nativeQuery=true)
	List<Ticket> findTicket(String fromPlace, String toPlace);  

	
}
