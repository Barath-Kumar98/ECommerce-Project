package com.training.service;

public interface IBuyer {

}
