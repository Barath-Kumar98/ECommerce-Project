package com.training.service;

import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.model.Product;
import com.training.repository.ProductRepository;
 
 
@Service
public class ProductService {

    @Autowired
    ProductRepository productRepo;


    public void addProduct(Product product) {
        productRepo.save(product);
    }

    public List<Product> getAllProduct() {
        return productRepo.findAll();
    }
 
    public void updateProduct(Product product) {
 
        Product existingproduct = productRepo.findById(product.getPid()).orElse(null);

            existingproduct.setBrandName(product.getBrandName());
            existingproduct.setCategory(product.getCategory());
            existingproduct.setImage(product.getImage());
            existingproduct.setProductModel(product.getProductModel());
            existingproduct.setProductname(product.getProductname());
            existingproduct.setProductPrice(product.getProductPrice());
            existingproduct.setProductSpecs(product.getProductSpecs());
            existingproduct.setQuantity(product.getQuantity());
            existingproduct.setSellerId(product.getSellerId());
            existingproduct.setStatus(product.getStatus());
            existingproduct.setSubCategory(product.getSubCategory());
            productRepo.save(existingproduct);
 
    }
 
    public List<Product> getProductBySeller(int id) {
        return productRepo.findBySellerId(id);
    }
 
    public List<Product> getProductByCategory(String category) {
        // TODO Auto-generated method stub
        return productRepo.findProductByCategory(category);
    }
 
}