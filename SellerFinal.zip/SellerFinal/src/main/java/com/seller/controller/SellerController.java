package com.seller.controller;

import java.util.List;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seller.entity.Seller;
import com.seller.service.SellerService;




@RestController
@RequestMapping("/seller")
public class SellerController {

	@Autowired
	SellerService sellerService;
	
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello Hello";
	}

	
	
	@GetMapping("/getSeller")
//	@RolesAllowed({"ROLE_SELLER"})
	public List<Seller> getSeller() {
		return sellerService.getSeller();
	}
	
	@GetMapping("/getSellerById/{id}")
	public Seller getSellerById(@PathVariable("id") int id) {
		return sellerService.getSellerById(id);
	}
	
	@PostMapping("/createSeller")
	public void createSeller(@RequestBody Seller seller) {
		sellerService.createSeller(seller);
	}
	
	@DeleteMapping("/deleteSeller/{id}")
	public int deleteSeller(@PathVariable("id") int id) {
		sellerService.deleteSeller(id);
		return id;
	}
	
	
	
}
