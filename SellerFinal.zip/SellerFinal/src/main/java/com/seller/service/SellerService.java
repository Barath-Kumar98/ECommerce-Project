package com.seller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seller.entity.Seller;
import com.seller.exception.MissingUserIdException;
import com.seller.repository.SellerRepository;

@Service
public class SellerService {
	
	@Autowired
	SellerRepository sellerRepo;
	
	public void createSeller(Seller seller) {
		sellerRepo.save(seller);
		
	}

	public List<Seller> getSeller() {
		// TODO Auto-generated method stub
		return sellerRepo.findAll();
	}

	public void deleteSeller(int id) {
		sellerRepo.deleteById(id);
	}

	public Seller getSellerById(int id) throws MissingUserIdException {
		
			Seller seller = sellerRepo.findById(id).orElse(null);
			if(seller == null) {
				throw new MissingUserIdException("USERID NOT PRESENT");
			}
			else 
			{
				return seller;
			}
	}
	
}
