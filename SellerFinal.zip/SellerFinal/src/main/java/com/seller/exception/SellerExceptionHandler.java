package com.seller.exception;

public class SellerExceptionHandler extends RuntimeException{

//    public MissingUsernameException(String exception) {
//        super(exception);
//        System.out.println(exception);
//    }
	
	public void MissingUserIdException(String exception) {
		System.out.println("exception");
	}
}
