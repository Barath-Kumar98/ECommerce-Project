package com.seller.exception;

public class MissingUserIdException extends RuntimeException{
	public MissingUserIdException(String exception) {
		super(exception);
		System.out.println(exception);
	}
}
