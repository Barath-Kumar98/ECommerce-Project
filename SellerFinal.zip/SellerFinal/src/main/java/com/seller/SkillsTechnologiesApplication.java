package com.seller;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class SkillsTechnologiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillsTechnologiesApplication.class, args);
	}

}

@RestController
class Sample
{
	@PostMapping("/addProduct")
	public void addProduct(@RequestBody Product product) {	
		RestTemplate rtemp=new RestTemplate();
		HttpHeaders head = new HttpHeaders();
//		HttpEntity httpEntity = new HttpEntity<>(head);
		HttpEntity<Product> entity = new HttpEntity<Product>(product, head);		
		rtemp.exchange("http://localhost:8932/product/addProduct", HttpMethod.POST, entity, void.class);

	}

	@PutMapping("/updateProduct")
	public void updateProduct(@RequestBody Product product) {

		RestTemplate rtemp=new RestTemplate();
		HttpHeaders head = new HttpHeaders();
//		HttpEntity httpEntity = new HttpEntity<>(head);
		HttpEntity<Product> entity = new HttpEntity<Product>(product, head);		
		rtemp.exchange("http://localhost:8932/product/updateProduct", HttpMethod.PUT, entity, void.class);

	}		

	@GetMapping("/getAllProductsBySellerId/{id}")
	public ResponseEntity<List<Product>> getProductBySeller(@PathVariable("id") int id) {
		RestTemplate rtemp=new RestTemplate();
		HttpHeaders head = new HttpHeaders();
		HttpEntity httpEntity = new HttpEntity<>(head);

//		rtemp.getForEntity("http://localhost:8916/product/GetAllProducts", Object.class);
		ResponseEntity<List<Product>> exchange = rtemp.exchange("http://localhost:8932/product/getProductBySeller/"+id, 
				HttpMethod.GET, httpEntity, new ParameterizedTypeReference<List<Product>>() {});
		return exchange;
	}

	
		
	@GetMapping("/getAllProducts")
	public ResponseEntity<List<Product>> getAllProduct() {
		RestTemplate rtemp=new RestTemplate();
		HttpHeaders head = new HttpHeaders();
		HttpEntity httpEntity = new HttpEntity<>(head);

//		rtemp.getForEntity("http://localhost:8916/product/GetAllProducts", Object.class);
		ResponseEntity<List<Product>> exchange = rtemp.exchange("http://localhost:8932/product/GetAllProducts", 
				HttpMethod.GET, httpEntity, new ParameterizedTypeReference<List<Product>>() {});
		return exchange;
	}
	
	@GetMapping("/getHello")
	public ResponseEntity<String> getHello() {
		RestTemplate rtemp=new RestTemplate();
		
		HttpHeaders head = new HttpHeaders();
		HttpEntity httpEntity = new HttpEntity<>(head);

//		rtemp.getForEntity("http://localhost:8916/product/hello", Object.class);
		return rtemp.exchange("http://localhost:8989/mentorportal/skillService/product/hello", HttpMethod.GET, httpEntity, String.class);		
	}
}

